<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="یک آپلودر فایل خفن">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/assets/stylesheets/style.css">
    <title>Upload File</title>
    <script src="/assets/scripts/side.js"></script>
</head>
<body onload="dumb()">
        <form method="POST" enctype="multipart/form-data" action="/upload.php">
        <label for="file" class="main">یک فایل انتخاب کنید:</label>
        <input type="file" id="file" name="file"><br />
        <input type="submit" value="آپلود فایل" class="main submit">
    </form>
    </body>
</html>

<!-- Cloud Action : https://cloud.midline.ir/gjtV2SC7oKiPoNuxfCnkTS9Pw66qwccOTFnXRkQowxbT8gPbUry_B9-9HEXYAg4rTLBlun5fE9HbOMghRmMpq6q2LKdXeE2PXEjrM912V8DwkY6EOQBq5hu7e0YQH0_M4muAvVwMESuxSKI8/uploadFile -->
